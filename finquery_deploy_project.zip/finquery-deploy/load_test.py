"""Send N requests with bounded concurrency to simulate the regulatory-filings workload."""
import asyncio, sys, time, httpx
N, CONC, URL = int(sys.argv[1]) if len(sys.argv) > 1 else 200, 20, "http://localhost:8000/analyze"
DOCS = ["The company disclosed a penalty and a pending litigation matter in its annual filing.",
        "Quarterly report shows revenue growth of 8 percent with no restatement.",
        "Risk factors: interest-rate exposure, supply chain disruption and regulatory change."]
async def one(c, i, sem, res):
    async with sem:
        r = await c.post(URL, json={"document_id": f"filing-{i}", "text": DOCS[i % 3]})
        res.append(r.status_code)
async def main():
    sem, res, t0 = asyncio.Semaphore(CONC), [], time.time()
    async with httpx.AsyncClient(timeout=30) as c:
        await asyncio.gather(*(one(c, i, sem, res) for i in range(N)))
    dt = time.time() - t0
    print(f"{N} requests in {dt:.1f}s -> {N/dt:.1f} req/s | ok={res.count(200)} errors={N-res.count(200)}")
asyncio.run(main())
