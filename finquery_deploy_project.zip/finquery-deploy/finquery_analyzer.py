"""FinQuery analyzer: LangChain-style regulatory-filing analysis service, instrumented with
OpenTelemetry (traces) and prometheus_client (metrics).

Stand-in for the course starter: the LLM is simulated (latency + occasional 429) so the service
runs without an API key. Replace `call_llm` with a real LangChain chain in production.

Endpoints: POST /analyze   GET /healthz (liveness)   GET /readyz (readiness)   GET /metrics
"""
import asyncio, logging, os, random, time

from fastapi import FastAPI, HTTPException, Response
from pydantic import BaseModel, Field
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from opentelemetry import trace
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("finquery")

# ---------- OpenTelemetry tracing (initialised first, at startup) ----------
provider = TracerProvider(resource=Resource.create({"service.name": "finquery-analyzer"}))
if os.getenv("OTEL_EXPORTER_OTLP_ENDPOINT"):            # send to an OTel Collector when configured
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
    provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
elif os.getenv("OTEL_CONSOLE_TRACES") == "1":           # local debugging
    provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
trace.set_tracer_provider(provider)
tracer = trace.get_tracer("finquery.analyzer")

# ---------- Prometheus metrics ----------
REQUESTS = Counter("finquery_requests_total", "Analyze requests", ["status"])
LATENCY = Histogram("finquery_request_duration_seconds", "End-to-end request latency",
                    buckets=(0.05, 0.1, 0.25, 0.5, 0.75, 1, 1.5, 2.5, 5, 10))
STAGE = Histogram("finquery_stage_duration_seconds", "Per-stage latency", ["stage"],
                  buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5))
INFLIGHT = Gauge("finquery_inflight_requests", "Requests currently being processed")
LLM_ERRORS = Counter("finquery_llm_errors_total", "Failed LLM calls")

LLM_ERROR_RATE = float(os.getenv("LLM_ERROR_RATE", "0.05"))
app = FastAPI(title="FinQuery Analyzer")
ready = True

class AnalyzeRequest(BaseModel):
    document_id: str
    text: str = Field(min_length=1, max_length=200_000)

class AnalyzeResponse(BaseModel):
    document_id: str
    summary: str
    risk_flags: list[str]
    latency_ms: int

async def timed(stage: str, coro):
    """Run one pipeline stage inside an OTel span and record its latency histogram."""
    with tracer.start_as_current_span(stage):
        t0 = time.perf_counter()
        try:
            return await coro
        finally:
            STAGE.labels(stage).observe(time.perf_counter() - t0)

async def fetch_document(doc_id: str, text: str) -> str:       # CPU/IO-ish stage
    await asyncio.sleep(random.uniform(0.02, 0.06))
    return text.strip()

async def call_llm(text: str) -> str:                          # I/O-bound stage (simulated)
    await asyncio.sleep(random.uniform(0.2, 0.8))
    if random.random() < LLM_ERROR_RATE:
        LLM_ERRORS.inc()
        raise RuntimeError("simulated upstream 429")
    return f"Analysis: {text[:120]}"

async def summarize(raw: str) -> tuple[str, list[str]]:        # logic stage
    await asyncio.sleep(random.uniform(0.005, 0.015))
    flags = [w for w in ("penalty", "restatement", "litigation") if w in raw.lower()]
    return " ".join(raw.split()[:25]), flags

@app.post("/analyze", response_model=AnalyzeResponse)
async def analyze(req: AnalyzeRequest):
    t0 = time.perf_counter()
    INFLIGHT.inc()
    try:
        with tracer.start_as_current_span("analyze_request") as span:
            span.set_attribute("document.id", req.document_id)
            text = await timed("fetch_document", fetch_document(req.document_id, req.text))
            raw = await timed("llm_call", call_llm(text))
            summary, flags = await timed("summarize", summarize(raw))
        REQUESTS.labels("ok").inc()
        return AnalyzeResponse(document_id=req.document_id, summary=summary, risk_flags=flags,
                               latency_ms=int((time.perf_counter() - t0) * 1000))
    except Exception:
        REQUESTS.labels("error").inc()
        log.exception("analyze failed doc=%s", req.document_id)   # detail in logs only
        raise HTTPException(status_code=502, detail="Analysis temporarily unavailable. Please retry.")
    finally:
        LATENCY.observe(time.perf_counter() - t0)
        INFLIGHT.dec()

@app.get("/healthz")
async def healthz():          # liveness: process is up
    return {"status": "ok"}

@app.get("/readyz")
async def readyz():           # readiness: safe to receive traffic
    if not ready:
        raise HTTPException(status_code=503, detail="not ready")
    return {"status": "ready"}

@app.get("/metrics")
async def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
