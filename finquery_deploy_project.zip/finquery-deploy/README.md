# FinQuery Analyzer: Deploy and Monitor

## Run locally
```bash
pip install -r requirements.txt
uvicorn finquery_analyzer:app --port 8000
python load_test.py 300
curl localhost:8000/metrics
```

## Build and push to AWS ECR
```bash
export AWS_REGION=us-east-1 ACCOUNT_ID=123456789012
docker build -t finquery-analyzer:1.0 .
docker images | grep finquery-analyzer
aws ecr create-repository --repository-name finquery-analyzer --region $AWS_REGION
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com
docker tag finquery-analyzer:1.0 $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/finquery-analyzer:1.0
docker push $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/finquery-analyzer:1.0
```
Edit `image:` in `k8s/deployment.yaml` (ACCOUNT_ID, REGION). On minikube/kind, the cluster needs pull access to ECR (imagePullSecret) or load the image locally.

## Deploy to Kubernetes
```bash
kubectl apply -f k8s/deployment.yaml -f k8s/service.yaml
kubectl get pods
kubectl describe deployment finquery-analyzer
kubectl get svc
kubectl port-forward svc/finquery-analyzer 8000:80     # then run load_test.py
```
If no OTel Collector is deployed, remove the OTEL_EXPORTER_OTLP_ENDPOINT env var from the Deployment.

## Prometheus
Add `k8s/prometheus-scrape-config.yaml` to your Prometheus config, open Status > Targets to confirm it is UP, then in the Graph UI try:
```
rate(finquery_requests_total[1m])
histogram_quantile(0.95, sum by (le) (rate(finquery_request_duration_seconds_bucket[5m])))
histogram_quantile(0.95, sum by (le, stage) (rate(finquery_stage_duration_seconds_bucket[5m])))
rate(finquery_requests_total{status="error"}[5m]) / rate(finquery_requests_total[5m])
```
Take your screenshot of these graphs for Requirement 2.
