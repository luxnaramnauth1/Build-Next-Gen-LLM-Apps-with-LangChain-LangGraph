"""gRPC RetrieverService. Stateless: no per-user state kept between requests."""
import logging, time
from concurrent import futures
import grpc
from grpc_reflection.v1alpha import reflection

import service_pb2, service_pb2_grpc
from retriever import retrieve

DEFAULT_TOP_K, MAX_TOP_K, PORT = 3, 10, 50051
log = logging.getLogger("retriever")

class RetrieverService(service_pb2_grpc.RetrieverServiceServicer):
    def GetDocuments(self, request, context):
        t0 = time.time()
        if not request.query.strip():
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, "query must not be empty")
        top_k = request.top_k or DEFAULT_TOP_K
        if not 1 <= top_k <= MAX_TOP_K:
            context.abort(grpc.StatusCode.INVALID_ARGUMENT, f"top_k must be between 1 and {MAX_TOP_K}")
        try:
            docs = [service_pb2.Document(id=d.metadata["id"], title=d.metadata["title"], content=d.page_content, score=s)
                    for d, s in retrieve(request.query, top_k)]
        except Exception:
            log.exception("retrieval failed")  # details in logs only
            context.abort(grpc.StatusCode.INTERNAL, "retrieval failed")
        ms = int((time.time() - t0) * 1000)
        log.info("GetDocuments query=%r top_k=%d returned=%d latency=%dms", request.query, top_k, len(docs), ms)
        return service_pb2.GetDocumentsResponse(documents=docs, latency_ms=ms)

def serve():
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=8))
    service_pb2_grpc.add_RetrieverServiceServicer_to_server(RetrieverService(), server)
    names = (service_pb2.DESCRIPTOR.services_by_name["RetrieverService"].full_name, reflection.SERVICE_NAME)
    reflection.enable_server_reflection(names, server)  # lets grpcurl work without the .proto
    server.add_insecure_port(f"[::]:{PORT}")
    server.start()
    log.info("RetrieverService listening on localhost:%d", PORT)
    server.wait_for_termination()

if __name__ == "__main__":
    serve()
