"""External test client (Python equivalent of a grpcurl call)."""
import grpc, service_pb2, service_pb2_grpc

def call(stub, **kw):
    try:
        return stub.GetDocuments(service_pb2.GetDocumentsRequest(**kw), timeout=3)
    except grpc.RpcError as e:
        return f"ERROR {e.code().name}: {e.details()}"

with grpc.insecure_channel("localhost:50051") as ch:
    stub = service_pb2_grpc.RetrieverServiceStub(ch)
    print("--- 1. valid request: query='How do I reset my API key?', top_k=2")
    print(call(stub, query="How do I reset my API key?", top_k=2))
    print("--- 2. default top_k")
    r = call(stub, query="webhook retry backoff"); print([d.id for d in r.documents], f"{r.latency_ms}ms")
    print("--- 3. empty query ->", call(stub, query="  "))
    print("--- 4. top_k=99 ->", call(stub, query="rate limit", top_k=99))
