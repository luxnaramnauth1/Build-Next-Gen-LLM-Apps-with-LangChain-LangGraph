"""LangChain retriever used by the service (keyword-overlap; swap for a vector store in production)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent.parent))
from techdocs_monolith import KeywordRetriever  # reuse the exact monolith logic

def retrieve(query: str, top_k: int):
    q = set(query.lower().split())
    retriever = KeywordRetriever(k=top_k)
    for d in retriever.invoke(query):
        words = set(d.page_content.lower().split())
        score = len(q & words) / max(1, len(q))
        yield d, min(1.0, score)
