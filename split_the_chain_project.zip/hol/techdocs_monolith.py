"""Stand-in for the course starter: monolithic TechDocs Q&A (retriever -> LLM -> summarizer).
Uses a fake LLM so it runs without an API key."""
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever

DOCS = [
    Document(page_content="To reset your API key, open Settings > Security > API Keys and click Regenerate. Old keys stop working immediately.", metadata={"id": "doc-1", "title": "Resetting API keys"}),
    Document(page_content="Rate limits are 100 requests per minute per key. Exceeding the limit returns HTTP 429 with a Retry-After header.", metadata={"id": "doc-2", "title": "Rate limits"}),
    Document(page_content="Webhooks are retried up to five times with exponential backoff if your endpoint returns a non-2xx status.", metadata={"id": "doc-3", "title": "Webhook retries"}),
    Document(page_content="Single sign-on (SSO) supports SAML 2.0 and OIDC. Configure it under Settings > Authentication.", metadata={"id": "doc-4", "title": "SSO setup"}),
    Document(page_content="Data exports are available as CSV or JSON from the Reports page and are retained for 30 days.", metadata={"id": "doc-5", "title": "Data exports"}),
]

class KeywordRetriever(BaseRetriever):
    docs: list = DOCS
    k: int = 3
    def _get_relevant_documents(self, query, *, run_manager=None):
        q = set(query.lower().split())
        scored = sorted(self.docs, key=lambda d: -len(q & set(d.page_content.lower().split())))
        return scored[: self.k]

def fake_llm(question, context):          # I/O-bound in real life (OpenAI call)
    return f"Based on the docs: {context[0].page_content}"

def summarize(text, max_words=25):        # logic-bound post-processing
    return " ".join(text.split()[:max_words])

def answer(question):
    ctx = KeywordRetriever().invoke(question)   # CPU-bound
    return summarize(fake_llm(question, ctx))

if __name__ == "__main__":
    print(answer("How do I reset my API key?"))
