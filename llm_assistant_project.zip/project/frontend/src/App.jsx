import { useState, useRef, useEffect } from "react";

// Extract the (possibly incomplete) "answer" string from streaming JSON so users see readable text.
function extractAnswer(raw) {
  const m = raw.match(/"answer"\s*:\s*"((?:[^"\\]|\\.)*)/);
  if (!m) return "";
  return m[1].replace(/\\n/g, "\n").replace(/\\"/g, '"').replace(/\\\\/g, "\\");
}

// Custom hook: streams SSE from OUR backend (/api/chat) only.
function useChat() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  async function send(text) {
    const userMsg = { id: crypto.randomUUID(), role: "user", content: text };
    const botId = crypto.randomUUID();
    const history = [...messages, userMsg];
    setMessages([...history, { id: botId, role: "assistant", content: "", streaming: true }]);
    setLoading(true);
    const patch = (p) => setMessages((ms) => ms.map((m) => (m.id === botId ? { ...m, ...p } : m)));
    try {
      const res = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history.map(({ role, content }) => ({ role, content })) }),
      });
      if (!res.ok || !res.body) throw new Error("bad response");
      const reader = res.body.getReader(), dec = new TextDecoder();
      let buf = "", raw = "";
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const events = buf.split("\n\n"); buf = events.pop();
        for (const ev of events) {
          const type = /event: (\w+)/.exec(ev)?.[1];
          const data = JSON.parse(/data: (.*)/s.exec(ev)?.[1] || "{}");
          if (type === "delta") { raw += data.text; patch({ content: extractAnswer(raw) }); }
          if (type === "done") {
            const r = data.reply;
            patch({ content: r.answer, streaming: false, serverId: data.id, meta: { ...r, cached: data.cached } });
          }
          if (type === "error") patch({ content: data.message, streaming: false, error: true });
        }
      }
    } catch {
      patch({ content: "I couldn't reach the assistant. Please check your connection and try again.", streaming: false, error: true });
    } finally { setLoading(false); }
  }
  return { messages, loading, send };
}

function Feedback({ msg, onRate }) {
  const [rating, setRating] = useState(null);
  const [flagged, setFlagged] = useState(false);
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);
  const id = msg.serverId || msg.id;

  const post = (body) => fetch("/api/feedback", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message_id: id, ...body }) });
  const rate = (r) => { setRating(r); setSent(r === "up"); onRate(r); post({ rating: r, flagged }); };
  const flag = () => { setFlagged(true); post({ rating, flagged: true }); };
  const submitNote = () => { post({ rating, flagged, note }); setSent(true); };

  return (
    <div style={{ marginTop: 6, fontSize: 13 }}>
      <button aria-label="Thumbs up" onClick={() => rate("up")} disabled={rating === "up"}>👍</button>{" "}
      <button aria-label="Thumbs down" onClick={() => rate("down")} disabled={rating === "down"}>👎</button>{" "}
      <button onClick={flag} disabled={flagged}>{flagged ? "⚑ Flagged" : "⚑ Flag"}</button>
      {(rating === "down" || flagged) && !sent && (
        <div style={{ marginTop: 6 }}>
          <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="What didn't work?" maxLength={500} style={{ width: "70%" }} />{" "}
          <button onClick={submitNote}>Send</button>
        </div>
      )}
      {sent && <span style={{ color: "#666", marginLeft: 8 }}>Thanks for the feedback!</span>}
    </div>
  );
}

export default function App() {
  const { messages, loading, send } = useChat();
  const [input, setInput] = useState("");
  const [score, setScore] = useState({ up: 0, down: 0 });
  const bottom = useRef(null);
  useEffect(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), [messages]);

  const submit = (e) => { e.preventDefault(); if (!input.trim() || loading) return; send(input.trim()); setInput(""); };
  const rate = (r) => setScore((s) => ({ ...s, [r]: s[r] + 1 }));

  return (
    <div style={{ maxWidth: 680, margin: "0 auto", padding: 16, fontFamily: "system-ui, sans-serif" }}>
      <h2>Northwind Returns Assistant</h2>
      <p style={{ color: "#666", marginTop: -8 }}>Answers come only from our returns policy. Session feedback: 👍 {score.up} · 👎 {score.down}</p>
      <div style={{ minHeight: 320 }}>
        {messages.length === 0 && <p style={{ color: "#888" }}>Try: “I bought a tent 12 days ago, can I return it?”</p>}
        {messages.map((m) => (
          <div key={m.id} style={{ display: "flex", justifyContent: m.role === "user" ? "flex-end" : "flex-start", margin: "10px 0" }}>
            <div style={{ maxWidth: "80%", padding: "8px 12px", borderRadius: 12, whiteSpace: "pre-wrap",
              background: m.role === "user" ? "#2563eb" : m.error ? "#fef2f2" : "#f1f5f9", color: m.role === "user" ? "#fff" : "#111" }}>
              {m.content || (m.streaming ? "Thinking…" : "")}
              {m.streaming && m.content && <span>▍</span>}
              {m.meta && (
                <div style={{ fontSize: 12, color: "#555", marginTop: 6 }}>
                  {m.meta.policy_refs?.length > 0 && <>Based on policy: {m.meta.policy_refs.join(", ")} · </>}
                  Confidence: {m.meta.confidence}{m.meta.cached && " · instant (cached)"}
                  {m.meta.confidence === "low" && <div style={{ color: "#b45309" }}>⚠ I'm not fully sure. Please confirm with support.</div>}
                  {m.meta.clarifying_question && <div style={{ marginTop: 4, fontWeight: 600 }}>❓ {m.meta.clarifying_question}</div>}
                </div>
              )}
              {m.role === "assistant" && !m.streaming && !m.error && <Feedback msg={m} onRate={rate} />}
            </div>
          </div>
        ))}
        <div ref={bottom} />
      </div>
      <form onSubmit={submit} style={{ display: "flex", gap: 8 }}>
        <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask about returns, refunds, exchanges, warranty…" maxLength={1000} style={{ flex: 1, padding: 10 }} />
        <button disabled={loading || !input.trim()}>{loading ? "…" : "Send"}</button>
      </form>
    </div>
  );
}
