import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
// The UI only ever talks to our backend (proxied), never to OpenAI.
export default defineConfig({ plugins: [react()], server: { proxy: { "/api": "http://localhost:8000" } } });
