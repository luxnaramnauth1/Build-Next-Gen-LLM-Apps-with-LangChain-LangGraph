# Northwind Returns Assistant: Prompt to Production

## Run
```bash
# backend
cd backend && python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt && cp .env.example .env   # add OPENAI_API_KEY
uvicorn main:app --reload --port 8000

# frontend (new terminal)
cd frontend && npm install && npm run dev                  # http://localhost:5173
```
## Test with curl / Postman
```bash
curl -N -X POST localhost:8000/api/chat -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Can I return a gift card?"}]}'
curl localhost:8000/api/stats            # requests, cache_hits, retries, token totals
curl localhost:8000/api/feedback/stats
```
Ask the same question twice: the second response is `cached: true` and logs `CACHE_HIT`.
To see retries, set `REQUEST_TIMEOUT_S=0.05` and watch the `transient ... retry` log lines; the UI shows a friendly message, never a raw error.
