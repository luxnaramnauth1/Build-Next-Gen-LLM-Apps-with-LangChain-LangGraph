"""Northwind Returns Assistant: resilient middleware around the OpenAI API.

Timeouts, retries w/ exponential backoff + jitter, in-memory LRU/TTL cache, token-usage logging,
SSE streaming, output validation, friendly errors, feedback store.
Run: uvicorn main:app --reload --port 8000
"""
import asyncio, hashlib, json, logging, os, random, time, uuid
from collections import OrderedDict
from typing import Literal, Optional

import openai
from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, StreamingResponse
from pydantic import BaseModel, Field, ValidationError

from prompt import SYSTEM_PROMPT

load_dotenv()
MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
TIMEOUT_S = float(os.getenv("REQUEST_TIMEOUT_S", "20"))
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "3"))
CACHE_TTL_S = int(os.getenv("CACHE_TTL_S", "3600"))
CACHE_MAX = int(os.getenv("CACHE_MAX_ENTRIES", "500"))
MAX_USER_CHARS = 1000
MAX_HISTORY = 6  # last N messages sent to the model (cost control)
FEEDBACK_FILE = "feedback.jsonl"

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("assistant")

client = openai.AsyncOpenAI(timeout=TIMEOUT_S, max_retries=0)  # we own the retry policy
app = FastAPI(title="Returns Assistant Middleware")
app.add_middleware(CORSMiddleware, allow_origins=[os.getenv("ALLOWED_ORIGIN", "http://localhost:5173")],
                   allow_methods=["*"], allow_headers=["*"])

# ---------- schemas ----------
class Msg(BaseModel):
    role: Literal["user", "assistant"]
    content: str = Field(max_length=4000)

class ChatRequest(BaseModel):
    messages: list[Msg] = Field(min_length=1, max_length=50)

class AssistantReply(BaseModel):
    answer: str
    status: Literal["answered", "needs_clarification", "not_covered", "out_of_scope"]
    policy_refs: list[str] = []
    confidence: Literal["high", "medium", "low"] = "low"
    clarifying_question: Optional[str] = None

class Feedback(BaseModel):
    message_id: str
    rating: Optional[Literal["up", "down"]] = None
    flagged: bool = False
    note: Optional[str] = Field(default=None, max_length=500)

FALLBACK = AssistantReply(
    answer="Sorry, I couldn't produce a reliable answer. Please rephrase, or contact support@northwindgear.example.",
    status="not_covered", policy_refs=["P8"], confidence="low")

# ---------- cache (LRU + TTL) ----------
_cache: "OrderedDict[str, tuple[float, dict]]" = OrderedDict()
stats = {"requests": 0, "cache_hits": 0, "retries": 0, "failures": 0, "prompt_tokens": 0, "completion_tokens": 0}

def cache_key(messages: list[dict]) -> str:
    norm = [(m["role"], " ".join(m["content"].lower().split())) for m in messages]
    return hashlib.sha256(json.dumps([MODEL, norm]).encode()).hexdigest()

def cache_get(k: str):
    hit = _cache.get(k)
    if hit and time.time() - hit[0] < CACHE_TTL_S:
        _cache.move_to_end(k)
        return hit[1]
    _cache.pop(k, None)
    return None

def cache_put(k: str, v: dict):
    _cache[k] = (time.time(), v)
    while len(_cache) > CACHE_MAX:
        _cache.popitem(last=False)

# ---------- helpers ----------
def estimate_tokens(text: str) -> int:
    return max(1, len(text) // 4)  # rough fallback when the API returns no usage

def friendly_error(exc: Exception) -> str:
    if isinstance(exc, (openai.APITimeoutError, asyncio.TimeoutError)):
        return "The assistant is taking too long to respond. Please try again in a moment."
    if isinstance(exc, openai.RateLimitError):
        return "We're getting a lot of questions right now. Please try again shortly."
    if isinstance(exc, openai.APIConnectionError):
        return "I'm having trouble connecting. Please check back in a moment."
    return "Something went wrong on our side. Please try again."

def is_transient(exc: Exception) -> bool:
    return isinstance(exc, (openai.APITimeoutError, openai.APIConnectionError, openai.RateLimitError)) or \
        (isinstance(exc, openai.APIStatusError) and exc.status_code >= 500)

def sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"

async def open_stream_with_retry(messages: list[dict], rid: str):
    """Retry only until the stream is OPEN (before any token reaches the user) so output is never duplicated."""
    for attempt in range(MAX_RETRIES + 1):
        try:
            return await client.chat.completions.create(
                model=MODEL, messages=messages, stream=True, temperature=0.2, max_tokens=500,
                response_format={"type": "json_object"}, stream_options={"include_usage": True})
        except Exception as exc:
            if not is_transient(exc) or attempt == MAX_RETRIES:
                raise
            stats["retries"] += 1
            delay = min(8.0, 0.5 * 2 ** attempt) + random.uniform(0, 0.25)  # 0.5s, 1s, 2s... + jitter
            log.warning("rid=%s transient %s, retry %d/%d in %.2fs", rid, type(exc).__name__, attempt + 1, MAX_RETRIES, delay)
            await asyncio.sleep(delay)

def parse_reply(raw: str) -> AssistantReply:
    try:
        return AssistantReply.model_validate_json(raw)
    except (ValidationError, ValueError):
        return FALLBACK

# ---------- endpoints ----------
@app.post("/api/chat")
async def chat(req: ChatRequest):
    rid, t0 = uuid.uuid4().hex[:8], time.time()
    stats["requests"] += 1
    history = [m.model_dump() for m in req.messages][-MAX_HISTORY:]
    if history[-1]["role"] != "user" or not history[-1]["content"].strip():
        return JSONResponse({"error": "Please enter a question."}, status_code=400)
    history[-1]["content"] = history[-1]["content"][:MAX_USER_CHARS]
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, *history]
    key = cache_key(history)

    async def gen():
        cached = cache_get(key)
        if cached:
            stats["cache_hits"] += 1
            log.info("rid=%s CACHE_HIT latency=%.0fms", rid, (time.time() - t0) * 1000)
            yield sse("delta", {"text": cached["raw"]})
            yield sse("done", {"id": rid, "reply": cached["reply"], "cached": True})
            return
        raw, usage = "", None
        try:
            stream = await open_stream_with_retry(messages, rid)
            async for chunk in stream:
                if chunk.usage:
                    usage = chunk.usage
                if chunk.choices and chunk.choices[0].delta.content:
                    piece = chunk.choices[0].delta.content
                    raw += piece
                    yield sse("delta", {"text": piece})
        except Exception as exc:
            stats["failures"] += 1
            log.error("rid=%s FAILED %s: %s", rid, type(exc).__name__, exc)  # raw error stays in logs only
            yield sse("error", {"id": rid, "message": friendly_error(exc)})
            return
        reply = parse_reply(raw)
        p = usage.prompt_tokens if usage else estimate_tokens(json.dumps(messages))
        c = usage.completion_tokens if usage else estimate_tokens(raw)
        stats["prompt_tokens"] += p; stats["completion_tokens"] += c
        log.info("rid=%s OK status=%s conf=%s prompt_tok=%d completion_tok=%d (%s) latency=%.0fms",
                 rid, reply.status, reply.confidence, p, c, "api" if usage else "est", (time.time() - t0) * 1000)
        if reply is not FALLBACK:  # never cache a failed/invalid generation
            cache_put(key, {"raw": raw, "reply": reply.model_dump()})
        yield sse("done", {"id": rid, "reply": reply.model_dump(), "cached": False})

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache"})

@app.post("/api/feedback")
async def feedback(fb: Feedback):
    record = {**fb.model_dump(), "ts": time.time()}
    with open(FEEDBACK_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
    log.info("FEEDBACK %s", record)
    return {"ok": True}

@app.get("/api/feedback/stats")
async def feedback_stats():
    up = down = flags = 0
    try:
        for line in open(FEEDBACK_FILE, encoding="utf-8"):
            r = json.loads(line)
            up += r["rating"] == "up"; down += r["rating"] == "down"; flags += bool(r["flagged"])
    except FileNotFoundError:
        pass
    return {"up": up, "down": down, "flags": flags}

@app.get("/api/stats")
async def get_stats():
    return {**stats, "cache_size": len(_cache), "model": MODEL}

@app.get("/health")
async def health():
    return {"ok": True}
